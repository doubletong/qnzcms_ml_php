CKEDITOR.plugins.setLang('lineheight','zh-cn', {
    title: '行高'
} );
