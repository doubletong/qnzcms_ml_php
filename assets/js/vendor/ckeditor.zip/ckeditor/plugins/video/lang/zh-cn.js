CKEDITOR.plugins.setLang('video', 'zh-cn', {
  button: '视频',
  title: '视频属性',
  emptySrc: 'URL 不能为空.',
  controls: '打开控制',
  mutedLoopingAutoplay: '柔和 循环 自动播放',
  preview: '预览',
  invalidSrc: 'URL无效或视频无法播放.'
});
